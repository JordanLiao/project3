#include "Node.hpp"

/**
 * constructor for Node
 */

Node::Node(int i): prev(nullptr), id(i), core(0), degree(0), dist(-1) {}

/**
 * add an incoming friend edge
 */

void Node::addIncomingFriend(Node * incoming) {
	incomingFriend.push_back(incoming);
}

/**
 * add an outgoing friend edge
 */

void Node::addOutgoingFriend(Node * outgoing) {
	outgoingFriend.push_back(outgoing);
}

