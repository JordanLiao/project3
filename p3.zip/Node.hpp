#include <iostream>
#include <vector>

using namespace std;

class Node {
	public:
		// previous node on the path
		Node * prev;
		// id of this node
		int id;
		// core of this node 
		int core;
		// degree of the node
		int degree;
		// current distance to this ndoe
		int dist;
		// those that this node considers to be friend
		vector<Node *> outgoingFriend;
		// those that consider this node to be friend
		vector<Node *> incomingFriend;

		Node(int);
		// add a node that consider this node a friend
		void addIncomingFriend(Node *);
		// add a node that this node considers to be a friend
		void addOutgoingFriend(Node *);
};

class NodeComp {
	public:
	bool operator()(Node*& l, Node*& r) const {
		//if((l->incomingFriend).size() != (r->incomingFriend).size())
			//return ((l->incomingFriend).size()) < ((r->incomingFriend).size());
		//else
			return (l->degree) < (r->degree);
	}
};

class IdComp {
	public:
	bool operator()(Node* l, Node* r) const {
			return (l->id) < (r->id);
	}
};
