#include <vector>
#include <string>
#include <sstream>
#include <fstream>
#include <iostream>

#include "Graph.hpp"

using namespace std;

int main(int argc, char* argv[]) {
	Graph g;

	char* graphfile = argv[1];
	char* queryfile = argv[2];
	char* outputfile = argv[3];

	g.loadDirectedGraph(graphfile);

	ofstream ofile(outputfile);

	// load the query pairs
	ifstream query(queryfile);
	while(query) {
		string s;
		if(!getline(query, s))
			break;

		istringstream ss(s);
		vector<int> pair;

		while(ss) {
			string str;
			if(!getline(ss, str, ' '))
				break;
			int temp;
			// if the input num is a proper integer
			if(str == string("0") || str[0] != '0') {
				istringstream(str) >> temp;
				pair.push_back(temp);
			}
			// if the input num is not 0 but starts with a 0
			else {
				temp = -1;
				pair.push_back(temp);
			}
		}

		// if not exactly 2 numbers are inputted
		if(pair.size() != 3)
			continue;

		// attempt to find the nodes in the graph
		Node * nd1 = g.findNode(pair[0]);
		Node * nd2 = g.findNode(pair[1]);

		// if either of them is not found, output 0 for no path
		if(nd1 == nullptr || nd2 == nullptr) {
			ofile << 0 << endl;
			continue;
		}

		// attempt to find the number of paths
		int count = g.xlengthpath(nd1, nd2, pair[2]);
		ofile << count << endl;
	}

	ofile.close();
	query.close();
}
