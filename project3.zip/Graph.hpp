#ifndef GRAPH_HPP
#define GRAPH_HPP

#include <iostream>
#include <set>
#include "Node.hpp"
#include <unordered_map>

using namespace std;

class Graph {
 protected:
  //MAYBE ADD CLASS DATA STRUCTURE(S) HERE
	
	unordered_map<int, Node*> nodes;

 public:
  Graph(void);

  ~Graph(void);

  //MAYBE ADD SOME MORE METHODS HERE SO AS TO ANSWER QUESTIONS IN YOUR PA
	
	/**
	 * add to the first node the second node as friend
	 */
	void addRelation(int, int);

	/** 
	 * find a node in the graph
	 * if the node is not found return nullptr
	 */
	Node * findNode(int);

  /* YOU CAN MODIFY THIS IF YOU LIKE , in_filename : THE INPUT FILENAME */

	/**
	 * take in a file with relationship data and build a graph based on it
	 */
  bool loadFromFile(const char* in_filename);
	
	/**
	 * take in a file with relationship data and build a directed graph based 
	 * on it
	 */
  bool loadDirectedGraph(const char* in_filename);

	/**
	 * attempt to find a path between two nodes in the graph
	 */
  vector<Node*> pathfinder(Node* from, Node* to);
    
	/**
	 * find how many people are allowed to attend a gathering with min of k 
	 * friends
	 */
  vector<Node *> socialgathering(const int& k);

	/**
	 * find the number of paths from one Node to another with exactly x edges
	 */
	int xlengthpath(Node * from, Node * to, int x);

};

#endif  // GRAPH_HPP
