#include "Graph.hpp"
//#include "Node.hpp"
#include <algorithm>
#include <fstream>
#include <iostream>
#include <limits>
#include <set>
#include <sstream>
#include <string>
#include <utility>
#include <queue>

using namespace std;

/**
 * constructor
 */

Graph::Graph(void){
}

/**
 * destructor
 */

Graph::~Graph(void) {
	for(unordered_map<int, Node*>::iterator i = nodes.begin(); i != nodes.end(); 
	i++) {
		delete(i->second);
	}
}

/* Add a node to the graph representing person with id idNumber and add a connection between two nodes in the graph. */
//TODO

/**
 * add to the first node a new friend
 */

void Graph::addRelation(int node, int friendNode) {
	Node * nd;
	Node * fnd;
	// if node is not found
	if(nodes.find(node) == nodes.end()) {
		nd = new Node(node);
		nodes.insert({node, nd});
	}
	// if node is found
	else {
		nd = nodes.find(node)->second;
	}
	if(nodes.find(friendNode) == nodes.end()) {
		fnd = new Node(friendNode);
		nodes.insert({friendNode, fnd});
	}
	else {
		fnd = nodes.find(friendNode)->second;
	}
	nd->addOutgoingFriend(fnd);
	//fnd->addIncomingFriend(nd);
}

/**
 * find a node in the graph
 */

Node* Graph::findNode(int id) {
	if(nodes.empty())
		return nullptr;
	if(nodes.find(id) != nodes.end()) {
		return nodes[id];
	}
	else
		return nullptr;
}
 
/** 
 *Read in relationships from an inputfile to create a graph 
 */

bool Graph::loadFromFile(const char* in_filename) {
  ifstream infile(in_filename);

  while (infile) {
    string s;
    if (!getline(infile, s)) break;

    istringstream ss(s);
    vector<string> record;

    while (ss) {
      string s;
   		if(!getline(ss, s, ' '))
				break;
			record.push_back(s);
    }

    if (record.size() != 2) {
      continue;
    }
		
		int temp;
		vector<int> pair;
		istringstream(record[0]) >> temp;
		pair.push_back(temp);
		istringstream(record[1]) >> temp;
		pair.push_back(temp);

    //TODO - YOU HAVE THE PAIR OF IDS OF 2 FRIENDS IN 'RECORD'. WHAT DO NEED TO DO NOW?
		//simulate undirected graph by creating two opposite edges
    addRelation(pair[0], pair[1]);  
    addRelation(pair[1], pair[0]);  
  }

  if (!infile.eof()) {
    cerr << "Failed to read " << in_filename << "!\n";
    return false;
  }

  infile.close();
  return true;
}

/** 
 *Read in relationships from an inputfile to create a directed graph 
 */

bool Graph::loadDirectedGraph(const char* in_filename) {
  ifstream infile(in_filename);

  while (infile) {
    string s;
    if (!getline(infile, s)) break;

    istringstream ss(s);
    vector<string> record;

    while (ss) {
      string s;
   		if(!getline(ss, s, ' '))
				break;
			record.push_back(s);
    }

    if (record.size() != 2) {
      continue;
    }
		
		int temp;
		vector<int> pair;
		istringstream(record[0]) >> temp;
		pair.push_back(temp);
		istringstream(record[1]) >> temp;
		pair.push_back(temp);

		//simulate directed graph by creating one outgoing edge 
    addRelation(pair[0], pair[1]);   
  }

  if (!infile.eof()) {
    cerr << "Failed to read " << in_filename << "!\n";
    return false;
  }

  infile.close();
  return true;
}

/**
 * attempt to find a path between two nodes; return a vector of pointers
 * to the nodes on the path, or an empty vector if none found
 */

vector<Node*> Graph::pathfinder(Node* from, Node* to) {
	//reset dist and prev
	for(unordered_map<int, Node*>::iterator i = nodes.begin(); i != nodes.end(); i++) {
		(i->second)->dist = -1;
		(i->second)->prev = nullptr;
	}
	// set source dist to 0
	from->dist = 0;
	bool foundPath = false;
	queue<Node*> que;
	que.push(from);
	while(que.size() != 0) {
		Node * curr = que.front();
		que.pop();
		int currFriendSize = (curr->outgoingFriend).size();
		vector<Node *> f = (curr->outgoingFriend);
		for(int i = 0; i < currFriendSize; i++) {
			// if friend is not visited
			if(f[i]->dist == -1) {
				f[i]->dist = curr->dist + 1;
				f[i]->prev = curr;
				que.push(f[i]);
			}
		}
		// if a path is found, end searching
		if(curr == to) {
			foundPath = true;
			break;
		}
	}

	//if path is not found
	if(!foundPath) {
		vector<Node *> a(0);
		return a;
	}

	// back tracing the path
	vector<Node *> path;
	Node * curr = to;
	while(curr != from) {
		path.push_back(curr);
		curr = curr->prev;
	}
	path.push_back(from);
	reverse(path.begin(), path.end());
	
	return path;
}



/* Implement social gathering*/
//TODO
vector<Node *> Graph::socialgathering(const int& k) {
	// k core algorithm
	vector<Node*> list;
	for(unordered_map<int, Node*>::iterator i = nodes.begin(); i != 
	nodes.end(); i++) {
		(i->second)->degree = ((i->second)->outgoingFriend).size();
		list.push_back(i->second);
	}
	vector<Node*> resultList = list;
	
	while(!list.empty()) {
		vector<Node*>::iterator pos = min_element(list.begin(), list.end(), NodeComp());
		Node * curr = *pos;
		curr->core = curr->degree;
		for(unsigned int j = 0; j < (curr->outgoingFriend).size(); j++) {
			if((curr->outgoingFriend)[j]->degree > curr->degree) {
				(curr->outgoingFriend)[j]->degree = (curr->outgoingFriend)[j]->
				degree - 1;
			}
		}
		list.erase(pos);
	}
	
	vector<Node *> result;
	for(unsigned int i = 0; i < resultList.size(); i++) {
		if(resultList[i]->core >= k) {
			result.push_back(resultList[i]);
		}
	}
	return result;
}

/**
 * find the number of paths from one node to another with exactly x edges
 */

int Graph::xlengthpath(Node * from, Node * to, int x) {
	// if edge limit has been reached
	if(x < 0)
		return 0;
	// if this is the last edge
	else if(x == 0) {
		if(from == to)
			return 1;
		else
			return 0;
	}
	else {
		int count = 0;
	 	vector<Node *> possiblePath = from->outgoingFriend;
		// recursively search down the neighbors
	 	for(unsigned int i = 0; i < possiblePath.size(); i++) {
	 		count += xlengthpath(possiblePath[i], to, x - 1);
	 	}
		return count;
	}
}
